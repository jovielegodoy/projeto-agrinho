let cena = "inicio"; // Pode ser: "inicio", "campo", "cidade", "comparacao"
let btnCampo, btnCidade, btnVoltar;
let xSol = 0;
let nuvens = [];
let animais = [];
let carros = [];
let predios = [];
let arvores = [];
let dados = {
  campo: {
    vantagens: ["Ar puro", "Alimentos frescos", "Contato com a natureza"],
    desafios: ["Acesso limitado a serviços", "Distância dos centros urbanos"]
  },
  cidade: {
    vantagens: ["Acesso a serviços", "Oportunidades de emprego", "Variedade cultural"],
    desafios: ["Poluição", "Trânsito intenso", "Estresse urbano"]
  }
};

function preload() {
  // Aqui você pode carregar imagens se quiser
  // Exemplo: imgCampo = loadImage('campo.jpg');
}

function setup() {
  createCanvas(800, 500);
  
  // Cria botões
  btnCampo = createButton('Vida no Campo');
  btnCampo.position(width/2 - 100, height/2 + 50);
  btnCampo.size(200, 40);
  btnCampo.mousePressed(() => cena = "campo");
  btnCampo.hide();
  
  btnCidade = createButton('Vida na Cidade');
  btnCidade.position(width/2 - 100, height/2 + 100);
  btnCidade.size(200, 40);
  btnCidade.mousePressed(() => cena = "cidade");
  btnCidade.hide();
  
  btnVoltar = createButton('Voltar');
  btnVoltar.position(20, 20);
  btnVoltar.size(80, 30);
  btnVoltar.mousePressed(() => cena = "inicio");
  btnVoltar.hide();
  
  // Cria nuvens
  for (let i = 0; i < 5; i++) {
    nuvens.push({
      x: random(width),
      y: random(50, 150),
      speed: random(0.5, 1.5),
      size: random(30, 70)
    });
  }
  
  // Cria animais do campo
  for (let i = 0; i < 4; i++) {
    animais.push({
      x: random(width),
      y: random(350, 450),
      type: floor(random(3)), // 0: vaca, 1: galinha, 2: cavalo
      speed: random(0.5, 2)
    });
  }
  
  // Cria carros da cidade
  for (let i = 0; i < 3; i++) {
    carros.push({
      x: random(width),
      y: 430,
      speed: random(2, 5),
      color: color(random(100, 255), random(100, 255), random(100, 255))
    });
  }
  
  // Cria prédios
  for (let i = 0; i < 6; i++) {
    predios.push({
      x: 50 + i * 120,
      height: random(100, 250),
      windows: []
    });
    
    // Adiciona janelas
    for (let j = 0; j < 5; j++) {
      for (let k = 0; k < 3; k++) {
        predios[i].windows.push({
          x: 10 + k * 30,
          y: 10 + j * 30,
          on: random() > 0.5
        });
      }
    }
  }
  
  // Cria árvores do campo
  for (let i = 0; i < 8; i++) {
    arvores.push({
      x: random(width),
      y: random(350, 450),
      size: random(40, 80)
    });
  }
}

function draw() {
  background(135, 206, 235); // Céu azul
  
  // Anima o sol
  xSol = (xSol + 0.5) % (width + 100);
  
  // Desenha o sol
  fill(255, 255, 0);
  noStroke();
  ellipse(xSol - 50, 80, 80, 80);
  
  // Desenha e anima nuvens
  for (let nuvem of nuvens) {
    nuvem.x += nuvem.speed;
    if (nuvem.x > width + 50) nuvem.x = -50;
    
    fill(255);
    ellipse(nuvem.x, nuvem.y, nuvem.size);
    ellipse(nuvem.x + 15, nuvem.y + 5, nuvem.size * 0.8);
    ellipse(nuvem.x - 15, nuvem.y - 5, nuvem.size * 0.7);
  }
  
  // Desenha o chão (base)
  fill(34, 139, 34); // Verde grama
  rect(0, 400, width, 100);
  
  // Mostra a cena atual
  if (cena === "inicio") {
    telaInicio();
  } else if (cena === "campo") {
    cenaCampo();
  } else if (cena === "cidade") {
    cenaCidade();
  } else if (cena === "comparacao") {
    cenaComparacao();
  }
}

function telaInicio() {
  // Esconde botões das outras cenas
  btnVoltar.hide();
  
  // Mostra título
  fill(0);
  textSize(48);
  textAlign(CENTER, CENTER);
  text("Campo e Cidade", width/2, height/3);
  
  // Mostra subtítulo
  textSize(24);
  text("Projeto Agrinho", width/2, height/3 + 60);
  
  // Mostra botões de escolha
  btnCampo.show();
  btnCidade.show();
  
  // Instrução
  textSize(18);
  text("Escolha um modo de vida para explorar:", width/2, height/2);
}

function cenaCampo() {
  // Configura botões
  btnCampo.hide();
  btnCidade.hide();
  btnVoltar.show();
  
  // Grama mais escura
  fill(0, 100, 0);
  rect(0, 400, width, 100);
  
  // Desenha árvores
  for (let arvore of arvores) {
    // Tronco
    fill(139, 69, 19);
    rect(arvore.x - 5, arvore.y, 10, -arvore.size/2);
    
    // Copa
    fill(0, 128, 0);
    ellipse(arvore.x, arvore.y - arvore.size/2, arvore.size);
  }
  
  // Animais
  for (let animal of animais) {
    animal.x += animal.speed;
    if (animal.x > width + 30) animal.x = -30;
    
    if (animal.type === 0) {
      // Vaca
      fill(255);
      ellipse(animal.x, animal.y, 50, 30);
      fill(0);
      // Manchas
      ellipse(animal.x + 5, animal.y - 5, 15, 10);
      ellipse(animal.x - 5, animal.y + 3, 20, 12);
    } else if (animal.type === 1) {
      // Galinha
      fill(255);
      ellipse(animal.x, animal.y, 30, 25);
      fill(255, 200, 0);
      triangle(animal.x + 12, animal.y, animal.x + 20, animal.y - 5, animal.x + 20, animal.y + 5);
    } else {
      // Cavalo
      fill(160, 82, 45);
      rect(animal.x - 20, animal.y - 15, 40, 30, 5);
    }
  }
  
  // Informações sobre o campo
  fill(0);
  textSize(20);
  textAlign(LEFT);
  text("Vida no Campo - Benefícios:", 30, 120);
  
  textSize(16);
  for (let i = 0; i < dados.campo.vantagens.length; i++) {
    text("✓ " + dados.campo.vantagens[i], 50, 150 + i * 30);
  }
  
  textSize(20);
  text("Desafios:", 30, 270);
  
  textSize(16);
  for (let i = 0; i < dados.campo.desafios.length; i++) {
    text("✗ " + dados.campo.desafios[i], 50, 300 + i * 30);
  }
  
  // Botão para comparação
  fill(50, 150, 50);
  rect(width - 200, height - 70, 180, 40, 10);
  fill(255);
  textSize(18);
  textAlign(CENTER, CENTER);
  text("Comparar com cidade", width - 110, height - 50);
}

function cenaCidade() {
  // Configura botões
  btnCampo.hide();
  btnCidade.hide();
  btnVoltar.show();
  
  // Asfalto
  fill(50);
  rect(0, 400, width, 100);
  
  // Faixas da rua
  fill(255);
  for (let x = 0; x < width; x += 60) {
    rect(x, 450, 30, 10);
  }
  
  // Prédios
  for (let predio of predios) {
    fill(70, 70, 80);
    rect(predio.x, 400, 100, -predio.height);
    
    // Janelas
    for (let janela of predio.windows) {
      if (random() > 0.99) janela.on = !janela.on; // Pisca aleatoriamente
      fill(janela.on ? 255 : 100);
      rect(predio.x + janela.x, 400 - predio.height + janela.y, 20, 20);
    }
  }
  
  // Carros
  for (let carro of carros) {
    carro.x += carro.speed;
    if (carro.x > width + 50) carro.x = -50;
    
    fill(carro.color);
    rect(carro.x, carro.y, 60, 30, 5);
    fill(0);
    rect(carro.x + 5, carro.y + 25, 15, 5); // Roda
    rect(carro.x + 40, carro.y + 25, 15, 5); // Roda
  }
  
  // Informações sobre a cidade
  fill(255);
  textSize(20);
  textAlign(LEFT);
  text("Vida na Cidade - Benefícios:", 30, 120);
  
  textSize(16);
  for (let i = 0; i < dados.cidade.vantagens.length; i++) {
    text("✓ " + dados.cidade.vantagens[i], 50, 150 + i * 30);
  }
  
  textSize(20);
  text("Desafios:", 30, 270);
  
  textSize(16);
  for (let i = 0; i < dados.cidade.desafios.length; i++) {
    text("✗ " + dados.cidade.desafios[i], 50, 300 + i * 30);
  }
  
  // Botão para comparação
  fill(50, 150, 50);
  rect(width - 200, height - 70, 180, 40, 10);
  fill(255);
  textSize(18);
  textAlign(CENTER, CENTER);
  text("Comparar com campo", width - 110, height - 50);
}

function cenaComparacao() {
  // Tela de comparação entre campo e cidade
  background(220);
  
  // Título
  fill(0);
  textSize(32);
  textAlign(CENTER);
  text("Comparação: Campo vs Cidade", width/2, 50);
  
  // Coluna do campo
  fill(150, 200, 150);
  rect(50, 100, 300, 350, 10);
  
  // Título campo
  fill(0);
  textSize(24);
  text("Vida no Campo", 200, 130);
  
  // Vantagens campo
  textSize(18);
  text("Vantagens:", 200, 170);
  textSize(16);
  for (let i = 0; i < dados.campo.vantagens.length; i++) {
    text("✓ " + dados.campo.vantagens[i], 70, 200 + i * 30);
  }
  
  // Desafios campo
  textSize(18);
  text("Desafios:", 200, 300);
  textSize(16);
  for (let i = 0; i < dados.campo.desafios.length; i++) {
    text("✗ " + dados.campo.desafios[i], 70, 330 + i * 30);
  }
  
  // Coluna da cidade
  fill(200, 200, 250);
  rect(450, 100, 300, 350, 10);
  
  // Título cidade
  fill(0);
  textSize(24);
  text("Vida na Cidade", 600, 130);
  
  // Vantagens cidade
  textSize(18);
  text("Vantagens:", 600, 170);
  textSize(16);
  for (let i = 0; i < dados.cidade.vantagens.length; i++) {
    text("✓ " + dados.cidade.vantagens[i], 470, 200 + i * 30);
  }
  
  // Desafios cidade
  textSize(18);
  text("Desafios:", 600, 300);
  textSize(16);
  for (let i = 0; i < dados.cidade.desafios.length; i++) {
    text("✗ " + dados.cidade.desafios[i], 470, 330 + i * 30);
  }
  
  // Botão voltar
  btnVoltar.show();
}

function mousePressed() {
  // Verifica clique nos botões de comparação
  if (cena === "campo" || cena === "cidade") {
    if (mouseX > width - 200 && mouseX < width - 20 && 
        mouseY > height - 70 && mouseY < height - 30) {
      cena = "comparacao";
    }
  }
}